<div>
    <h1><?=$news['title']?></h1>
    <p><?=$news['text']?></p>
</div>
<div>
    <a href="/news">Все новости</a>
</div>

