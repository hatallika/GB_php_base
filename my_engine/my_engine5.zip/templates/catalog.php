<h2>Каталог</h2>
<!--<?php var_dump($catalog);?>-->
<div>
    <div>
        <h2>Пицца</h2>
        <img src="./img/pizza.jpeg" alt="Пицца" width="150"><br>
        Цена: 24 <br>
        <button>Купить</button>
        <hr>
    </div>
    <div>
        <h2>Чай</h2>
        <img src="./img/tea.png" alt="Чай" width="150"><br>
        Цена: 1 <br>
        <button>Купить</button>
        <hr>
    </div>
    <div>
        <h2>Яблоко</h2>
        <img src="./img/apple.jpg" alt="Яблоко" width="150"><br>
        Цена: 12 <br>
        <button>Купить</button>
        <hr>
    </div>
</div>