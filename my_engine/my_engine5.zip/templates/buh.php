<h2>Список файлов</h2>
<?php foreach($files as $file):?>
    <a href="/docs/<?=$file?>"><?=$file?> </a><br>
<?php endforeach;?>