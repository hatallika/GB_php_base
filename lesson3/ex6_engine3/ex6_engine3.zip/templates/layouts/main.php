<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?=$title?></title>
    <link rel="stylesheet" href="/css/style.css?<?=rand(1,22232)?>">
</head>
<body>
<?=$menu?>
<?=$content?>
</body>
</html>