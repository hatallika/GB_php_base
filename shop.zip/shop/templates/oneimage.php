<div class="post_title">
    <h2>Фото: <?=$files['name']?></h2>
</div>

<div class="gallery">
    <div class="oneimages">
        <img class="oneimages_img" src="/gallery_img/big/<?=$files['name']?>" width="500" />
    </div>
    <div>Количество просмотров: <?=$files['views']?></div>
    <div class="back"><a href="/gallery">Назад</a></div>
</div>
